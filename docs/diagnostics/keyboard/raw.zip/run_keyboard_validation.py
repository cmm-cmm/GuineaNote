import json
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
out = root / 'target' / ('keyboard-validation-' + str(time.time_ns()))
out.mkdir()
(root / 'target/keyboard-validation-latest-path.txt').write_text(str(out), encoding='utf-8')
probes = [('keyboard', 'pty_keyboard.py', []), ('smoke', 'pty_smoke.py', []),
          ('search', 'pty_search.py', ['--trace']), ('tabs', 'pty_tabs.py', []),
          ('dialogs-mouse', 'pty_dialog_mouse.py', []), ('project', 'pty_project.py', []),
          ('workspace', 'pty_workspace.py', []), ('agent', 'pty_agent.py', []),
          ('recovery', 'pty_recovery.py', []), ('terminal-matrix', 'terminal_matrix.py', []),
          ('latency-trace', 'pty_interaction_latency.py', []),
          ('latency-off', 'pty_interaction_latency.py', ['--no-trace'])]
results = []
for name, script, args in probes:
    path = out / (name + '.txt')
    with path.open('wb') as stream:
        process = subprocess.run([sys.executable, '-X', 'utf8', str(root / 'scripts' / script), *args], stdout=stream, stderr=subprocess.STDOUT)
    results.append({'name': name, 'script': script, 'args': args, 'exit': process.returncode})
    (out / 'results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    if process.returncode:
        print(path.read_text(encoding='utf-8')[-6000:], flush=True)
        raise RuntimeError('Probe failed: ' + name)
    print('PASS ' + name, flush=True)
print(out, flush=True)
